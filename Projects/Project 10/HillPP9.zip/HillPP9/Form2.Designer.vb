﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtB0G0 = New System.Windows.Forms.TextBox()
        Me.txtTeamName = New System.Windows.Forms.TextBox()
        Me.txtB3G1 = New System.Windows.Forms.TextBox()
        Me.txtB3G2 = New System.Windows.Forms.TextBox()
        Me.txtB3G0 = New System.Windows.Forms.TextBox()
        Me.txtB2G2 = New System.Windows.Forms.TextBox()
        Me.txtB2G1 = New System.Windows.Forms.TextBox()
        Me.txtB2G0 = New System.Windows.Forms.TextBox()
        Me.txtB1G2 = New System.Windows.Forms.TextBox()
        Me.txtB1G1 = New System.Windows.Forms.TextBox()
        Me.txtB1G0 = New System.Windows.Forms.TextBox()
        Me.txtB0G2 = New System.Windows.Forms.TextBox()
        Me.txtB0G1 = New System.Windows.Forms.TextBox()
        Me.lblTeamName = New System.Windows.Forms.Label()
        Me.lblGame1 = New System.Windows.Forms.Label()
        Me.lblGame3 = New System.Windows.Forms.Label()
        Me.lblGame2 = New System.Windows.Forms.Label()
        Me.lblBowler4 = New System.Windows.Forms.Label()
        Me.lblBowler3 = New System.Windows.Forms.Label()
        Me.lblBowler2 = New System.Windows.Forms.Label()
        Me.lblBowler1 = New System.Windows.Forms.Label()
        Me.btnRecordScores = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'txtB0G0
        '
        Me.txtB0G0.Location = New System.Drawing.Point(108, 86)
        Me.txtB0G0.Name = "txtB0G0"
        Me.txtB0G0.Size = New System.Drawing.Size(50, 20)
        Me.txtB0G0.TabIndex = 0
        '
        'txtTeamName
        '
        Me.txtTeamName.Location = New System.Drawing.Point(120, 32)
        Me.txtTeamName.Name = "txtTeamName"
        Me.txtTeamName.Size = New System.Drawing.Size(194, 20)
        Me.txtTeamName.TabIndex = 1
        '
        'txtB3G1
        '
        Me.txtB3G1.Location = New System.Drawing.Point(184, 164)
        Me.txtB3G1.Name = "txtB3G1"
        Me.txtB3G1.Size = New System.Drawing.Size(50, 20)
        Me.txtB3G1.TabIndex = 2
        '
        'txtB3G2
        '
        Me.txtB3G2.Location = New System.Drawing.Point(258, 164)
        Me.txtB3G2.Name = "txtB3G2"
        Me.txtB3G2.Size = New System.Drawing.Size(56, 20)
        Me.txtB3G2.TabIndex = 3
        '
        'txtB3G0
        '
        Me.txtB3G0.Location = New System.Drawing.Point(108, 164)
        Me.txtB3G0.Name = "txtB3G0"
        Me.txtB3G0.Size = New System.Drawing.Size(50, 20)
        Me.txtB3G0.TabIndex = 4
        '
        'txtB2G2
        '
        Me.txtB2G2.Location = New System.Drawing.Point(258, 138)
        Me.txtB2G2.Name = "txtB2G2"
        Me.txtB2G2.Size = New System.Drawing.Size(56, 20)
        Me.txtB2G2.TabIndex = 5
        '
        'txtB2G1
        '
        Me.txtB2G1.Location = New System.Drawing.Point(184, 138)
        Me.txtB2G1.Name = "txtB2G1"
        Me.txtB2G1.Size = New System.Drawing.Size(50, 20)
        Me.txtB2G1.TabIndex = 6
        '
        'txtB2G0
        '
        Me.txtB2G0.Location = New System.Drawing.Point(108, 138)
        Me.txtB2G0.Name = "txtB2G0"
        Me.txtB2G0.Size = New System.Drawing.Size(50, 20)
        Me.txtB2G0.TabIndex = 7
        '
        'txtB1G2
        '
        Me.txtB1G2.Location = New System.Drawing.Point(258, 112)
        Me.txtB1G2.Name = "txtB1G2"
        Me.txtB1G2.Size = New System.Drawing.Size(56, 20)
        Me.txtB1G2.TabIndex = 8
        '
        'txtB1G1
        '
        Me.txtB1G1.Location = New System.Drawing.Point(184, 112)
        Me.txtB1G1.Name = "txtB1G1"
        Me.txtB1G1.Size = New System.Drawing.Size(50, 20)
        Me.txtB1G1.TabIndex = 9
        '
        'txtB1G0
        '
        Me.txtB1G0.Location = New System.Drawing.Point(108, 112)
        Me.txtB1G0.Name = "txtB1G0"
        Me.txtB1G0.Size = New System.Drawing.Size(50, 20)
        Me.txtB1G0.TabIndex = 10
        '
        'txtB0G2
        '
        Me.txtB0G2.Location = New System.Drawing.Point(258, 86)
        Me.txtB0G2.Name = "txtB0G2"
        Me.txtB0G2.Size = New System.Drawing.Size(56, 20)
        Me.txtB0G2.TabIndex = 11
        '
        'txtB0G1
        '
        Me.txtB0G1.Location = New System.Drawing.Point(184, 86)
        Me.txtB0G1.Name = "txtB0G1"
        Me.txtB0G1.Size = New System.Drawing.Size(50, 20)
        Me.txtB0G1.TabIndex = 12
        '
        'lblTeamName
        '
        Me.lblTeamName.AutoSize = True
        Me.lblTeamName.Location = New System.Drawing.Point(50, 35)
        Me.lblTeamName.Name = "lblTeamName"
        Me.lblTeamName.Size = New System.Drawing.Size(65, 13)
        Me.lblTeamName.TabIndex = 13
        Me.lblTeamName.Text = "Team Name"
        '
        'lblGame1
        '
        Me.lblGame1.AutoSize = True
        Me.lblGame1.Location = New System.Drawing.Point(105, 70)
        Me.lblGame1.Name = "lblGame1"
        Me.lblGame1.Size = New System.Drawing.Size(44, 13)
        Me.lblGame1.TabIndex = 14
        Me.lblGame1.Text = "Game 1"
        '
        'lblGame3
        '
        Me.lblGame3.AutoSize = True
        Me.lblGame3.Location = New System.Drawing.Point(255, 70)
        Me.lblGame3.Name = "lblGame3"
        Me.lblGame3.Size = New System.Drawing.Size(44, 13)
        Me.lblGame3.TabIndex = 15
        Me.lblGame3.Text = "Game 3"
        '
        'lblGame2
        '
        Me.lblGame2.AutoSize = True
        Me.lblGame2.Location = New System.Drawing.Point(181, 70)
        Me.lblGame2.Name = "lblGame2"
        Me.lblGame2.Size = New System.Drawing.Size(44, 13)
        Me.lblGame2.TabIndex = 16
        Me.lblGame2.Text = "Game 2"
        '
        'lblBowler4
        '
        Me.lblBowler4.AutoSize = True
        Me.lblBowler4.Location = New System.Drawing.Point(50, 167)
        Me.lblBowler4.Name = "lblBowler4"
        Me.lblBowler4.Size = New System.Drawing.Size(48, 13)
        Me.lblBowler4.TabIndex = 17
        Me.lblBowler4.Text = "Bowler 4"
        '
        'lblBowler3
        '
        Me.lblBowler3.AutoSize = True
        Me.lblBowler3.Location = New System.Drawing.Point(50, 141)
        Me.lblBowler3.Name = "lblBowler3"
        Me.lblBowler3.Size = New System.Drawing.Size(48, 13)
        Me.lblBowler3.TabIndex = 18
        Me.lblBowler3.Text = "Bowler 3"
        '
        'lblBowler2
        '
        Me.lblBowler2.AutoSize = True
        Me.lblBowler2.Location = New System.Drawing.Point(50, 112)
        Me.lblBowler2.Name = "lblBowler2"
        Me.lblBowler2.Size = New System.Drawing.Size(48, 13)
        Me.lblBowler2.TabIndex = 19
        Me.lblBowler2.Text = "Bowler 2"
        '
        'lblBowler1
        '
        Me.lblBowler1.AutoSize = True
        Me.lblBowler1.Location = New System.Drawing.Point(50, 86)
        Me.lblBowler1.Name = "lblBowler1"
        Me.lblBowler1.Size = New System.Drawing.Size(48, 13)
        Me.lblBowler1.TabIndex = 20
        Me.lblBowler1.Text = "Bowler 1"
        '
        'btnRecordScores
        '
        Me.btnRecordScores.Location = New System.Drawing.Point(138, 201)
        Me.btnRecordScores.Name = "btnRecordScores"
        Me.btnRecordScores.Size = New System.Drawing.Size(140, 23)
        Me.btnRecordScores.TabIndex = 21
        Me.btnRecordScores.Text = "Record Scores"
        Me.btnRecordScores.UseVisualStyleBackColor = True
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(444, 251)
        Me.Controls.Add(Me.btnRecordScores)
        Me.Controls.Add(Me.lblBowler1)
        Me.Controls.Add(Me.lblBowler2)
        Me.Controls.Add(Me.lblBowler3)
        Me.Controls.Add(Me.lblBowler4)
        Me.Controls.Add(Me.lblGame2)
        Me.Controls.Add(Me.lblGame3)
        Me.Controls.Add(Me.lblGame1)
        Me.Controls.Add(Me.lblTeamName)
        Me.Controls.Add(Me.txtB0G1)
        Me.Controls.Add(Me.txtB0G2)
        Me.Controls.Add(Me.txtB1G0)
        Me.Controls.Add(Me.txtB1G1)
        Me.Controls.Add(Me.txtB1G2)
        Me.Controls.Add(Me.txtB2G0)
        Me.Controls.Add(Me.txtB2G1)
        Me.Controls.Add(Me.txtB2G2)
        Me.Controls.Add(Me.txtB3G0)
        Me.Controls.Add(Me.txtB3G2)
        Me.Controls.Add(Me.txtB3G1)
        Me.Controls.Add(Me.txtTeamName)
        Me.Controls.Add(Me.txtB0G0)
        Me.Name = "Form2"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtB0G0 As TextBox
    Friend WithEvents txtTeamName As TextBox
    Friend WithEvents txtB3G1 As TextBox
    Friend WithEvents txtB3G2 As TextBox
    Friend WithEvents txtB3G0 As TextBox
    Friend WithEvents txtB2G2 As TextBox
    Friend WithEvents txtB2G1 As TextBox
    Friend WithEvents txtB2G0 As TextBox
    Friend WithEvents txtB1G2 As TextBox
    Friend WithEvents txtB1G1 As TextBox
    Friend WithEvents txtB1G0 As TextBox
    Friend WithEvents txtB0G2 As TextBox
    Friend WithEvents txtB0G1 As TextBox
    Friend WithEvents lblTeamName As Label
    Friend WithEvents lblGame1 As Label
    Friend WithEvents lblGame3 As Label
    Friend WithEvents lblGame2 As Label
    Friend WithEvents lblBowler4 As Label
    Friend WithEvents lblBowler3 As Label
    Friend WithEvents lblBowler2 As Label
    Friend WithEvents lblBowler1 As Label
    Friend WithEvents btnRecordScores As Button
End Class
